# INSTALL.md — How to Apply This Update

This package (`Changes.zip`) contains **only** new/modified files, laid out in the exact
same folder structure as your existing DataSync project. You can copy the whole `app/`
folder tree straight over your project root and every file will land in its correct
place — or copy file-by-file using the table below if you prefer to review each change
individually (recommended for `strings.xml` and `AndroidManifest.xml`, which are
full-file replacements — see the ⚠ notes in `CHANGELOG.md`).

## Option A — Fast path (copy the whole tree)

1. Unzip `Changes.zip` somewhere temporary, e.g. `~/Downloads/Changes`.
2. From that folder, copy `app/` on top of your project's `app/` folder, allowing
   overwrite:
   ```bash
   cp -R ~/Downloads/Changes/app/*  /path/to/your/DataSync/app/
   cp ~/Downloads/Changes/firestore.rules /path/to/your/DataSync/firestore.rules
   ```
3. Continue to **"After copying"** below.

## Option B — File-by-file (safer if you've made local edits)

Copy each file to the exact destination path shown. All paths are relative to your
project root.

| # | File in this package | Paste to |
|---|---|---|
| 1 | `app/src/main/java/.../domain/repository/RegisterRepository.kt` | `app/src/main/java/com/bhushan/datasync/domain/repository/RegisterRepository.kt` |
| 2 | `app/src/main/java/.../data/repository/RegisterRepositoryImpl.kt` | `app/src/main/java/com/bhushan/datasync/data/repository/RegisterRepositoryImpl.kt` |
| 3 | `app/src/main/java/.../presentation/auth/RegisterViewModel.kt` | `app/src/main/java/com/bhushan/datasync/presentation/auth/RegisterViewModel.kt` |
| 4 | `app/src/main/java/.../presentation/auth/RegisterActivity.kt` | `app/src/main/java/com/bhushan/datasync/presentation/auth/RegisterActivity.kt` |
| 5 | `app/src/main/res/layout/activity_register.xml` | `app/src/main/res/layout/activity_register.xml` |
| 6 | `app/src/main/java/.../presentation/admin/UsersAdapter.kt` | `app/src/main/java/com/bhushan/datasync/presentation/admin/UsersAdapter.kt` |
| 7 | `app/src/main/res/layout/item_user.xml` | `app/src/main/res/layout/item_user.xml` |
| 8 | `app/src/main/java/.../domain/model/User.kt` | `app/src/main/java/com/bhushan/datasync/domain/model/User.kt` (overwrite) |
| 9 | `app/src/main/java/.../utils/Constants.kt` | `app/src/main/java/com/bhushan/datasync/utils/Constants.kt` (overwrite) |
| 10 | `app/src/main/java/.../data/repository/AuthRepositoryImpl.kt` | `app/src/main/java/com/bhushan/datasync/data/repository/AuthRepositoryImpl.kt` (overwrite) |
| 11 | `app/src/main/java/.../di/RepositoryModule.kt` | `app/src/main/java/com/bhushan/datasync/di/RepositoryModule.kt` (overwrite) |
| 12 | `app/src/main/java/.../presentation/auth/LoginActivity.kt` | `app/src/main/java/com/bhushan/datasync/presentation/auth/LoginActivity.kt` (overwrite) |
| 13 | `app/src/main/res/layout/activity_login.xml` | `app/src/main/res/layout/activity_login.xml` (overwrite) |
| 14 | `app/src/main/res/values/strings.xml` | `app/src/main/res/values/strings.xml` (⚠ merge if customized, see below) |
| 15 | `app/src/main/AndroidManifest.xml` | `app/src/main/AndroidManifest.xml` (⚠ merge if customized, see below) |
| 16 | `app/src/main/java/.../presentation/main/MainViewModel.kt` | `app/src/main/java/com/bhushan/datasync/presentation/main/MainViewModel.kt` (overwrite) |
| 17 | `app/src/main/java/.../presentation/main/MainActivity.kt` | `app/src/main/java/com/bhushan/datasync/presentation/main/MainActivity.kt` (overwrite) |
| 18 | `app/src/main/java/.../domain/repository/UserRepository.kt` | `app/src/main/java/com/bhushan/datasync/domain/repository/UserRepository.kt` (overwrite) |
| 19 | `app/src/main/java/.../data/repository/UserRepositoryImpl.kt` | `app/src/main/java/com/bhushan/datasync/data/repository/UserRepositoryImpl.kt` (overwrite) |
| 20 | `app/src/main/java/.../presentation/admin/AdminViewModel.kt` | `app/src/main/java/com/bhushan/datasync/presentation/admin/AdminViewModel.kt` (overwrite) |
| 21 | `app/src/main/java/.../presentation/admin/AdminPanelFragment.kt` | `app/src/main/java/com/bhushan/datasync/presentation/admin/AdminPanelFragment.kt` (overwrite) |
| 22 | `app/src/main/res/layout/fragment_admin_panel.xml` | `app/src/main/res/layout/fragment_admin_panel.xml` (overwrite) |
| 23 | `app/src/main/java/.../service/DataSyncFcmService.kt` | `app/src/main/java/com/bhushan/datasync/service/DataSyncFcmService.kt` (overwrite) |
| 24 | `firestore.rules` | project root `firestore.rules` (overwrite) |

### ⚠ Merge notes for `strings.xml` and `AndroidManifest.xml`

These two are shipped as complete files that **only add** new keys/entries on top of what
you already had (nothing was removed or renamed). If you have made your own edits to
either file since the version originally delivered:

- **strings.xml**: open both versions side-by-side and copy just the new `<string>`
  entries listed under "NEW STRINGS" in `CHANGELOG.md` item #14 into your existing file,
  rather than overwriting wholesale.
- **AndroidManifest.xml**: copy just the new `<activity android:name=".presentation.auth.RegisterActivity" ...>`
  block into your existing manifest's `<application>` section, rather than overwriting.

## After copying

1. **Re-sync Gradle** in Android Studio (`File → Sync Project with Gradle Files`) — no
   dependency versions changed, so this should be instant.
2. **Redeploy Firestore rules** (required — the new Admin "View Users" feature and admin
   role-management will fail with `PERMISSION_DENIED` until you do this):
   ```bash
   firebase deploy --only firestore:rules
   ```
3. **Clean + rebuild** to force regeneration of ViewBinding classes for the two new
   layouts (`ActivityRegisterBinding`, `ItemUserBinding`):
   ```bash
   ./gradlew clean assembleDebug
   ```
4. **Manual smoke test** (see `AUDIT_REPORT.md` Part 14 for the full checklist):
   - Launch app → Login screen → tap "Don't have an account? Create one" → Register a
     new user → confirm you land back on Login → sign in with the new account → confirm
     the Dashboard shows role `USER`.
   - In Firebase Console, promote that user's `role` to `ADMIN` → confirm the Admin menu
     item appears in the toolbar without needing to re-login.
   - Open Admin Panel → confirm the "All Users" list loads and shows every registered
     account with their role.
   - Toggle Development Mode → confirm it persists.
   - Tap Logout → confirm you land on Login and that pressing Back does **not** return
     to the Dashboard.

If anything doesn't compile after copying, it is almost certainly because a file above
was pasted to the wrong path — double-check the destination column, especially for the
Kotlin files (package declarations inside each file must match their folder location
exactly, since these were not renamed, only added-to/edited-in-place).
