# CHANGELOG — DataSync Update Package

This package contains **only** the files that are new or modified. Every entry lists the
old behavior, the new behavior, why the change was made, and exactly where to copy the
file in your existing project. See `INSTALL.md` for the step-by-step paste procedure and
`AUDIT_REPORT.md` for the full requirement-by-requirement verification this update is
based on.

---

## NEW FILES

### 1. `RegisterRepository.kt`
- **Why changed:** Part 5 requires a dedicated Registration feature with a "Register
  Repository" as a distinct file, separate from `AuthRepository` (which only handles
  sign-in of an existing account).
- **Old behavior:** Did not exist. There was no way to create a new account from inside
  the app.
- **New behavior:** Defines `register(name, email, password): Flow<Resource<User>>`.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/domain/repository/RegisterRepository.kt`

### 2. `RegisterRepositoryImpl.kt`
- **Why changed:** Implements the interface above.
- **New behavior:** Creates a Firebase Auth account via
  `createUserWithEmailAndPassword`, then writes `users/{uid}` with
  `uid, name, email, role="USER", devModeEnabled=false, createdAt, lastLogin`. Handles
  `FirebaseAuthUserCollisionException` (duplicate email), `FirebaseAuthWeakPasswordException`,
  and no-internet as distinct, user-friendly errors.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/data/repository/RegisterRepositoryImpl.kt`

### 3. `RegisterViewModel.kt`
- **Why changed:** MVVM layer for the Register screen; keeps `RegisterActivity` free of
  business logic, matching the pattern already used by `LoginViewModel`.
- **New behavior:** Validates Name / Email / Password / Confirm Password (required,
  email format, 6-char minimum, password match) before calling the repository; exposes
  `formState` (field errors) and `registerState` (`Resource<User>?`) as `StateFlow`.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/auth/RegisterViewModel.kt`

### 4. `RegisterActivity.kt`
- **Why changed:** The UI entry point for Part 5.
- **New behavior:** Collects `formState`/`registerState`, shows a progress indicator
  during the network call, shows inline field errors and a top-level error message on
  failure, and on success shows a confirmation toast and **navigates back to Login**
  (per the spec: "After registration → Navigate to Login").
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/auth/RegisterActivity.kt`

### 5. `activity_register.xml`
- **Why changed:** Layout for the new screen (Name / Email / Password / Confirm
  Password fields, error text, progress bar, "Already have an account? Sign in" link).
- **Copy to:** `app/src/main/res/layout/activity_register.xml`

### 6. `UsersAdapter.kt`
- **Why changed:** Part 3 explicitly requires verifying Admin can **"View Users"** — this
  was **missing** from the original build. This RecyclerView adapter renders the new
  Admin "All Users" list (name, email, role badge).
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/admin/UsersAdapter.kt`

### 7. `item_user.xml`
- **Why changed:** Row layout for the adapter above.
- **Copy to:** `app/src/main/res/layout/item_user.xml`

---

## MODIFIED FILES

### 8. `User.kt`
- **Why changed:** Registration requires `name` and `lastLogin` fields on the user
  profile that did not previously exist.
- **Old behavior:** `User(uid, email, role, fcmToken, devModeEnabled, lastSyncAt, createdAt)`
- **New behavior:** Adds `name: String = ""` and `lastLogin: Long = 0L`. Both have
  defaults, so this is a **non-breaking** change — every existing call site
  (`AuthRepositoryImpl`, Firestore deserialization) still compiles unchanged.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/domain/model/User.kt`

### 9. `Constants.kt`
- **Why changed:** New Firestore field names and FCM data-message action keys needed by
  Registration and the new FCM-triggered sync.
- **Old behavior:** No `FIELD_NAME`, `FIELD_LAST_LOGIN`, `FCM_DATA_ACTION_KEY`,
  `FCM_DATA_ACTION_SYNC`.
- **New behavior:** Adds those four constants.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/utils/Constants.kt`

### 10. `AuthRepositoryImpl.kt`
- **Why changed:** The `lastLogin` field needs to be stamped on every sign-in, not just
  at account creation.
- **Old behavior:** Only wrote `createdAt` once, at first-ever login.
- **New behavior:** After every successful login, updates `users/{uid}.lastLogin` to the
  current timestamp (non-fatal if it fails).
- **Copy to:** `app/src/main/java/com/bhushan/datasync/data/repository/AuthRepositoryImpl.kt`

### 11. `RepositoryModule.kt`
- **Why changed:** Wire the new `RegisterRepository` into Hilt.
- **Old behavior:** No binding for a register-specific repository.
- **New behavior:** Adds `@Binds abstract fun bindRegisterRepository(...): RegisterRepository`.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/di/RepositoryModule.kt`

### 12. `LoginActivity.kt`
- **Why changed:** Users need a way to reach the new Register screen from Login.
- **Old behavior:** No link to Registration.
- **New behavior:** Tapping "Don't have an account? Create one" launches `RegisterActivity`.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/auth/LoginActivity.kt`

### 13. `activity_login.xml`
- **Why changed:** Adds the "Create account" link text view referenced above.
- **Copy to:** `app/src/main/res/layout/activity_login.xml`

### 14. `strings.xml`
- **Why changed:** New user-facing text for Registration and the Admin "View Users"
  feature.
- **New behavior:** Adds `register_title`, `register_subtitle`, `name_hint`,
  `confirm_password_hint`, `btn_register`, `already_have_account`,
  `dont_have_account`, `manage_users_title`, `empty_users`.
- **Copy to:** `app/src/main/res/values/strings.xml`
- ⚠ **Merge carefully:** this is a full-file replacement of your existing `strings.xml`
  that only **adds** keys — nothing was removed or renamed. If you've customized any
  string since the original delivery, diff before overwriting (see INSTALL.md).

### 15. `AndroidManifest.xml`
- **Why changed:** Register the new `RegisterActivity`.
- **New behavior:** Adds an `<activity>` entry for
  `.presentation.auth.RegisterActivity`.
- **Copy to:** `app/src/main/AndroidManifest.xml`
- ⚠ **Merge carefully:** full-file replacement; re-check if you've made unrelated manifest
  edits since the original delivery.

### 16. `MainViewModel.kt`
- **Why changed:** Part 6 requires deterministic Logout — the original implementation
  fired `sessionManager.clearSession()` in a coroutine **without waiting for it**, while
  `MainActivity` navigated away immediately. This was a race condition, not a hard bug
  (Firebase sign-out was still synchronous-enough in practice), but it did not
  **guarantee** cleanup order.
- **Old behavior:** `logout()` called `cancelAllSync()` and `authRepository.logout()`
  synchronously, then launched an unobserved coroutine to clear the session.
- **New behavior:** `logout()` is now a single coroutine that awaits, **in order**:
  WorkManager cancel → Firebase sign-out → DataStore session clear → emits a
  `logoutComplete: SharedFlow<Unit>` event exactly once, after everything finished.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/main/MainViewModel.kt`

### 17. `MainActivity.kt`
- **Why changed:** Consumes the new deterministic `logoutComplete` event.
- **Old behavior:** Called `viewModel.logout()` then immediately built and fired the
  navigate-to-Login intent in the same function call.
- **New behavior:** Subscribes to `logoutComplete` **first**, then calls
  `viewModel.logout()`; navigation (with `FLAG_ACTIVITY_NEW_TASK | FLAG_ACTIVITY_CLEAR_TASK`,
  wiping the back stack) only happens once the ViewModel confirms all cleanup finished.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/main/MainActivity.kt`

### 18. `UserRepository.kt`
- **Why changed:** Part 3 requires Admin "View Users" — missing in the original build.
- **New behavior:** Adds `getAllUsers(): Flow<Resource<List<User>>>`.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/domain/repository/UserRepository.kt`

### 19. `UserRepositoryImpl.kt`
- **Why changed:** Implements `getAllUsers()`.
- **New behavior:** Realtime listener over the whole `users` collection, ordered by
  `createdAt`. A non-admin caller's query is rejected server-side by the updated
  Firestore rules (see below) and surfaces as `Resource.Error`, not a silently empty list.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/data/repository/UserRepositoryImpl.kt`

### 20. `AdminViewModel.kt`
- **Why changed:** Expose the new users list to the UI.
- **New behavior:** Adds `usersState: StateFlow<Resource<List<User>>>`, populated from
  `getAllUsers()` in `init {}`.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/admin/AdminViewModel.kt`

### 21. `AdminPanelFragment.kt`
- **Why changed:** Render the new users list.
- **New behavior:** Binds a `RecyclerView` (via `UsersAdapter`) to `usersState`, with its
  own loading/empty/error handling, alongside the existing Dev Mode toggle.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/presentation/admin/AdminPanelFragment.kt`

### 22. `fragment_admin_panel.xml`
- **Why changed:** Layout for the new users list section.
- **Old behavior:** Fixed-height `LinearLayout`, not scrollable — would have clipped a
  long user list.
- **New behavior:** Wraps the whole panel in a `NestedScrollView` and appends a "All
  Users" header, progress bar, empty-state text, and `RecyclerView`
  (`recyclerViewUsers`).
- **Copy to:** `app/src/main/res/layout/fragment_admin_panel.xml`

### 23. `DataSyncFcmService.kt`
- **Why changed:** Part 10 asks to verify "FCM Trigger" for WorkManager — the original
  service only displayed notifications; it never triggered a sync from a push message.
- **Old behavior:** `onMessageReceived` only rendered a notification.
- **New behavior:** If the incoming data payload has `action = "sync"`, immediately calls
  `SyncScheduler.triggerOneTimeSync()` before (optionally) also showing a notification —
  lets a backend push a "sync now" command to a specific device.
- **Copy to:** `app/src/main/java/com/bhushan/datasync/service/DataSyncFcmService.kt`

### 24. `firestore.rules`
- **Why changed:** Two real gaps found during the audit:
  1. Admin "View Users" needs to **read every** `users/{uid}` document, but the original
     rule only allowed `isOwner(uid)`.
  2. Admin **role management** (promoting/demoting another user) needs to **update**
     another user's document, but the original `update` rule was scoped to
     `isOwner(uid)` only — an Admin could not actually change anyone else's role despite
     the code intending to support it.
- **Old behavior:**
  ```
  allow read: if isOwner(uid);
  allow update: if isOwner(uid) && (request.resource.data.role == resource.data.role || isAdmin());
  ```
  (note: the old `isAdmin()` check in `update` was actually unreachable in practice for
  cross-user updates, since the whole rule was gated by `isOwner(uid)` first.)
- **New behavior:**
  ```
  allow read: if isOwner(uid) || isAdmin();
  allow update: if (isOwner(uid) && request.resource.data.role == resource.data.role) || isAdmin();
  ```
  Self-escalation is still impossible (a `USER` can never write their own `role` field),
  but an `ADMIN` can now legitimately read the full user directory and promote/demote
  any account.
- **Copy to:** project root, replacing `firestore.rules`. **You must redeploy this** —
  see INSTALL.md.

---

## Summary of files NOT changed (verified correct as-is)

`SyncManager.kt`, `SyncWorker.kt`, `SyncScheduler.kt`, `PermissionManager.kt`,
`BaseActivity.kt`, `BootCompletedReceiver.kt`, `SplashActivity.kt`, `SessionManager.kt`,
`NetworkUtils.kt`, `nav_graph.xml`, `bottom_nav_menu.xml`, `menu_main.xml`, all Dashboard /
Contacts / Call Logs / SMS / Records files, `Resource.kt`, `DateUtils.kt`,
`Extensions.kt`, and the Gradle/DI setup outside `RepositoryModule.kt` — all were
inspected during the audit (see `AUDIT_REPORT.md`) and found to already satisfy their
requirements with no changes needed.
