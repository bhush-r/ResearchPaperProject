package com.bhushan.datasync.presentation.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bhushan.datasync.domain.model.User
import com.bhushan.datasync.domain.repository.AuthRepository
import com.bhushan.datasync.domain.repository.UserRepository
import com.bhushan.datasync.sync.SyncScheduler
import com.bhushan.datasync.utils.Resource
import com.bhushan.datasync.utils.SessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val userRepository: UserRepository,
    private val sessionManager: SessionManager,
    private val syncScheduler: SyncScheduler
) : ViewModel() {

    private val _currentUser = MutableStateFlow<Resource<User>>(Resource.Loading)
    val currentUser: StateFlow<Resource<User>> = _currentUser.asStateFlow()

    val isLoggedIn: StateFlow<Boolean> = sessionManager.isLoggedInFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    /**
     * Fires exactly once, after ALL logout side-effects (WorkManager cancel,
     * FirebaseAuth signOut, DataStore/session clear) have completed. The
     * Activity waits for this event before navigating and clearing the task
     * stack -- this is what guarantees the back button can never return to
     * an authenticated screen after logout.
     */
    private val _logoutComplete = MutableSharedFlow<Unit>()
    val logoutComplete: SharedFlow<Unit> = _logoutComplete

    init {
        observeProfile()
    }

    private fun observeProfile() {
        val uid = authRepository.getCurrentUserId() ?: return
        viewModelScope.launch {
            userRepository.observeCurrentUser(uid).collect { resource ->
                _currentUser.value = resource
                if (resource is Resource.Success) {
                    sessionManager.updateRole(resource.data.role)
                    sessionManager.updateDevMode(resource.data.devModeEnabled)
                }
            }
        }
    }

    /**
     * Requirement (Part 6): complete logout.
     *  1) Cancel all scheduled/queued WorkManager sync jobs so nothing keeps
     *     writing to Firestore on behalf of a signed-out user.
     *  2) FirebaseAuth.signOut() -- ends the Firebase session.
     *  3) Clear the cached DataStore session (role/devMode/last-sync/uid).
     *  4) Emit [logoutComplete] so the Activity can safely navigate and wipe
     *     the back stack.
     */
    fun logout() {
        viewModelScope.launch {
            syncScheduler.cancelAllSync()
            authRepository.logout()
            sessionManager.clearSession()
            _logoutComplete.emit(Unit)
        }
    }
}
