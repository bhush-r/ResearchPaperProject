package com.bhushan.datasync.domain.repository

import com.bhushan.datasync.domain.model.User
import com.bhushan.datasync.utils.Resource
import kotlinx.coroutines.flow.Flow

interface UserRepository {

    /** Realtime listener on `users/{uid}` -- drives role/devMode changes across the UI instantly. */
    fun observeCurrentUser(uid: String): Flow<Resource<User>>

    /**
     * Admin-only: realtime listener over the entire `users` collection.
     * Firestore Security Rules gate this at the server: only a caller whose
     * OWN profile has role == "ADMIN" can successfully read this query (see
     * firestore.rules) -- a USER calling this will get a permission-denied
     * error surfaced as [Resource.Error], not an empty list, so this is safe
     * to expose without an extra client-side role check.
     */
    fun getAllUsers(): Flow<Resource<List<User>>>

    suspend fun updateFcmToken(uid: String, token: String)

    suspend fun updateLastSyncTimestamp(uid: String, timestamp: Long)

    /** Admin-only: toggles the Development Mode flag for their own profile. */
    suspend fun setDevMode(uid: String, enabled: Boolean): Resource<Unit>
}
