package com.bhushan.datasync.domain.repository

import com.bhushan.datasync.domain.model.User
import com.bhushan.datasync.utils.Resource
import kotlinx.coroutines.flow.Flow

/**
 * Dedicated contract for the Registration flow (kept separate from
 * [AuthRepository] on purpose, per the explicit "Register Repository" file
 * requirement -- it owns account CREATION, while [AuthRepository] owns
 * SIGN-IN of an already-existing account).
 */
interface RegisterRepository {

    /**
     * Creates a new Firebase Auth account with [email]/[password], then
     * creates the matching `users/{uid}` Firestore document with:
     *   uid, name, email, role = "USER", devModeEnabled = false,
     *   createdAt, lastLogin.
     * Emits [Resource.Loading] -> [Resource.Success] / [Resource.Error].
     */
    fun register(name: String, email: String, password: String): Flow<Resource<User>>
}
