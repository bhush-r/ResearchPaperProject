# DataSync — Android Machine Test

An enterprise-style Android application built in **Kotlin**, following **MVVM + Clean
Architecture + Repository Pattern**, backed by **Firebase Authentication, Firestore, and
Cloud Messaging**, with **role-based access control**, **device data sync (Contacts / Call
Logs / SMS)**, and **automatic background synchronization** via WorkManager.

Package: `com.bhushan.datasync` · Min SDK: 29 · Language: Kotlin · UI: XML (View Binding)

---

## Table of Contents

1. [Project Setup Instructions](#1-project-setup-instructions)
2. [Firebase Configuration Steps](#2-firebase-configuration-steps)
3. [Architecture Overview](#3-architecture-overview)
4. [Folder Structure](#4-folder-structure)
5. [Libraries Used](#5-libraries-used)
6. [Feature-to-Requirement Mapping](#6-feature-to-requirement-mapping)
7. [Firestore Data Model](#7-firestore-data-model)
8. [Security Rules Summary](#8-security-rules-summary)
9. [Duplicate Prevention Strategy](#9-duplicate-prevention-strategy)
10. [Sync Strategy (Manual / Automatic / Background)](#10-sync-strategy-manual--automatic--background)
11. [Error & Edge Case Handling](#11-error--edge-case-handling)
12. [Screenshots](#12-screenshots)
13. [Building a Release APK](#13-building-a-release-apk)

---

## 1. Project Setup Instructions

### Prerequisites
- Android Studio (latest stable, e.g. **Ladybug** or newer)
- JDK 17 (bundled with recent Android Studio)
- An Android device or emulator running **API 29+**
- A Google account to create a Firebase project

### Steps
1. **Open the project**: `File → Open` and select the `DataSync/` root folder.
2. **Let Gradle sync.** On first sync, Android Studio will download/regenerate the Gradle
   wrapper jar automatically (only `gradle-wrapper.properties` ships in this repo to keep
   it lightweight — this is standard and expected).
3. **Add your Firebase config** — see [section 2](#2-firebase-configuration-steps) below.
   The build will fail with a clear Google Services error until this file is in place.
4. **Run the app** on a device/emulator with API 29+. Grant Contacts / Call Log / SMS
   permissions when prompted (from the Dashboard screen) to exercise the sync features.
5. **Create a test user.** The app does not currently include a self-serve "Sign Up" screen
   (only Login, per the test's stated scope: *"Firebase Authentication using Email/Username
   and Password"*). Create your first user either:
   - In the Firebase Console → Authentication → Users → **Add user**, or
   - Temporarily call `FirebaseAuth.getInstance().createUserWithEmailAndPassword(...)` from
     a debug entry point.
   On first successful login, the app automatically creates the matching
   `users/{uid}` Firestore profile document with `role = "USER"`.
6. **Promote a user to Admin** (to see Admin-only features): open Firebase Console →
   Firestore → `users/{uid}` → edit the `role` field from `"USER"` to `"ADMIN"`. The
   Dashboard, toolbar menu, and Admin Panel all update live via a Firestore snapshot
   listener — no re-login needed.

---

## 2. Firebase Configuration Steps

1. Go to the [Firebase Console](https://console.firebase.google.com) and create a new
   project (or reuse an existing one).
2. **Add an Android app** to the project:
   - Package name: `com.bhushan.datasync`
   - (Optional) App nickname: `DataSync`
   - (Optional) Debug signing certificate SHA-1 — not required for Email/Password auth.
3. **Download `google-services.json`** and place it at `app/google-services.json`
   (a placeholder file with these same instructions is provided at
   `app/google-services.json.PLACEHOLDER` — replace it with the real file).
4. **Enable Authentication**:
   - Firebase Console → Build → Authentication → Sign-in method → enable **Email/Password**.
5. **Enable Firestore**:
   - Firebase Console → Build → Firestore Database → Create database → start in
     **Production mode** (the shipped `firestore.rules` already lock it down correctly).
6. **Deploy security rules** (requires the [Firebase CLI](https://firebase.google.com/docs/cli)):
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase use --add            # select your Firebase project
   firebase deploy --only firestore:rules
   ```
7. **Cloud Messaging** requires no extra console setup — it's enabled automatically the
   moment the Android app is registered in step 2. The app requests a token right after
   login and stores it on the user's profile (`users/{uid}.fcmToken`) and again whenever
   the token rotates (`FirebaseMessagingService.onNewToken`).
8. **Notifications permission (Android 13+)**: the manifest declares
   `POST_NOTIFICATIONS`; on API 33+ you may want to also request it at runtime from the
   Dashboard alongside the other three permissions if you plan to rely heavily on push
   notifications (not required for the core sync flows, which don't depend on notifications).

---

## 3. Architecture Overview

The app follows **Clean Architecture** inside a single Gradle module, split into three
layers:

```
presentation  →  domain  →  data
 (UI/ViewModel)  (contracts)  (Firebase/ContentResolver impls)
```

- **`presentation/`** — Activities, Fragments, ViewModels, Adapters. ViewModels expose
  `StateFlow` and depend **only** on `domain.repository` interfaces — never on Firebase
  types directly. This is what makes the layer swappable/testable.
- **`domain/`** — Pure Kotlin: `model` (data classes/enums) and `repository` (interfaces).
  Zero Android or Firebase imports.
- **`data/`** — `repository` package contains the real implementations
  (`AuthRepositoryImpl`, `ContactRepositoryImpl`, etc.) that talk to Firebase Auth,
  Firestore, and the device `ContentResolver`.
- **`di/`** — Hilt modules (`AppModule`, `FirebaseModule`, `RepositoryModule`) wire the
  interfaces to implementations and provide Firebase/WorkManager singletons.
- **`sync/`** — `SyncManager` (shared orchestration logic), `SyncWorker` (Hilt-injected
  `CoroutineWorker`), `SyncScheduler` (WorkManager periodic/one-time enqueue).
- **`permission/`** — `PermissionManager`, the single source of truth for runtime
  permission state.
- **`service/` / `receiver/`** — `DataSyncFcmService` (FCM), `BootCompletedReceiver`
  (re-arms periodic sync after reboot).
- **`utils/`** — `Resource<T>` (Loading/Success/Error wrapper used everywhere),
  `SessionManager` (DataStore-backed cached session/role/dev-mode), `NetworkUtils`,
  `DateUtils`, extension functions.

### Data flow example — "Sync Now" button
```
DashboardFragment
   → DashboardViewModel.syncNow()
      → SyncManager.syncAll(uid)              [shared with background worker]
         → ContactRepository.readDeviceContacts()   (ContentResolver)
         → ContactRepository.syncContacts(uid, ...) (Firestore batched writes,
                                                       deterministic doc IDs)
         → (same for CallLogRepository, SmsRepository)
         → UserRepository.updateLastSyncTimestamp(uid, now)
      ← emits SyncState via StateFlow at every stage
   ← DashboardFragment collects SyncState and updates the progress bar/label live
```

### Why StateFlow everywhere?
Every repository method that can be "loading / success / error" returns either a
`Flow<Resource<T>>` (for realtime Firestore listeners) or a `suspend fun ...: Resource<T>`
(for one-shot operations). ViewModels convert these into `StateFlow` so Fragments can
`collectFlow { }` safely inside `repeatOnLifecycle(STARTED)` — no leaks, no crashes on
rotation, and the loading/success/error UI states shown on **every single screen** in the
app come from the exact same `Resource` sealed class.

---

## 4. Folder Structure

```
DataSync/
├── firestore.rules                  # Firebase Security Rules
├── firebase.json / firestore.indexes.json
├── app/
│   ├── google-services.json.PLACEHOLDER   # replace with your real file
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/bhushan/datasync/
│       │   ├── DataSyncApplication.kt
│       │   ├── di/                  # AppModule, FirebaseModule, RepositoryModule
│       │   ├── utils/                # Resource, Constants, SessionManager,
│       │   │                         # NetworkUtils, DateUtils, Extensions
│       │   ├── permission/           # PermissionManager
│       │   ├── sync/                 # SyncManager, SyncWorker, SyncScheduler
│       │   ├── service/              # DataSyncFcmService
│       │   ├── receiver/             # BootCompletedReceiver
│       │   ├── domain/
│       │   │   ├── model/            # Role, User, ContactItem, CallLogItem,
│       │   │   │                     # SmsItem, RecordItem, SyncState, DashboardStats
│       │   │   └── repository/       # interfaces only
│       │   ├── data/
│       │   │   └── repository/       # Firebase/ContentResolver implementations
│       │   └── presentation/
│       │       ├── common/           # BaseActivity (auth guard)
│       │       ├── splash/
│       │       ├── auth/             # Login
│       │       ├── main/             # MainActivity shell + bottom nav + toolbar
│       │       ├── dashboard/
│       │       ├── contacts/
│       │       ├── calllogs/
│       │       ├── sms/
│       │       ├── records/          # CRUD feature
│       │       └── admin/            # Admin-only dev mode panel
│       └── res/
│           ├── layout/, menu/, navigation/, drawable/, values/, xml/, mipmap-anydpi-v26/
```

---

## 5. Libraries Used

| Category | Library |
|---|---|
| Language | Kotlin |
| Architecture | MVVM, Clean Architecture, Repository Pattern |
| DI | Hilt (`hilt-android`, `hilt-navigation-fragment`, `hilt-work`) |
| Async | Kotlin Coroutines, StateFlow/SharedFlow |
| Backend | Firebase Auth, Firebase Firestore (with offline persistence), Firebase Cloud Messaging |
| Background work | AndroidX WorkManager (+ Hilt-Work integration) |
| Local cache | AndroidX DataStore (Preferences) — session/role/dev-mode cache |
| UI | Material Design 3 Components, ConstraintLayout, SwipeRefreshLayout, RecyclerView |
| Navigation | AndroidX Navigation Component (Fragment + Safe Args plugin) |
| View binding | ViewBinding (no findViewById, no Kotlin synthetics) |

---

## 6. Feature-to-Requirement Mapping

| # | Requirement | Where it's implemented |
|---|---|---|
| 1–3 | Kotlin, MVVM, Git-friendly structure | Whole project; `.gitignore` excludes secrets/build output |
| 4 | Splash Screen | `presentation/splash/SplashActivity.kt` |
| 5 | Firebase email/password auth | `AuthRepositoryImpl.login()` |
| 6 | FCM token stored after login | `AuthRepositoryImpl.login()` + `DataSyncFcmService.onNewToken()` |
| 7–8 | Auth validation / route protection | `BaseActivity` re-checks `FirebaseAuth` on every `onStart()` |
| 9 | Session management | Firebase Auth persistence + `SessionManager` (DataStore) |
| 10 | Logout | `MainViewModel.logout()`, confirmation dialog in `MainActivity` |
| 11–13 | Admin/User roles, role-based nav | `Role` enum, `MainActivity` menu visibility, `AdminPanelFragment` self-guard |
| 14 | Dev Mode indicator | `DashboardFragment` (admin-only card), `AdminPanelFragment` (toggle) |
| 15 | Dashboard stats | `DashboardViewModel` + `DashboardRepositoryImpl` |
| 16 | CRUD | `RecordRepository` / `RecordsFragment` / `AddEditRecordBottomSheet` |
| 17 | RecyclerView everywhere | Contacts/CallLogs/SMS/Records all use `ListAdapter` + `DiffUtil` |
| 18 | Search & Filter | Per-feature ViewModel combine of search query (+ call-type filter) |
| 19 | Runtime permissions | `PermissionManager` + `ActivityResultContracts.RequestMultiplePermissions` in `DashboardFragment` |
| 20–21 | Read/sync Contacts | `ContactRepositoryImpl` |
| 22–23 | Read/sync Call Logs | `CallLogRepositoryImpl` |
| 24–25 | Read/sync SMS | `SmsRepositoryImpl` |
| 26 | Manual sync button | `DashboardFragment.btnSyncNow` → `SyncManager.syncAll()` |
| 27 | Automatic background sync | `SyncScheduler.schedulePeriodicSync()` (WorkManager, every 15 min) |
| 28 | Sync progress/status | `SyncState` sealed class, live-collected in `DashboardFragment` |
| 29 | Duplicate prevention | Deterministic Firestore document IDs — see [section 9](#9-duplicate-prevention-strategy) |
| 30–31 | Screen/CRUD protection | `BaseActivity`, Firestore rules, `AdminPanelFragment` role re-check |
| 32–33 | Firebase Security Rules | `firestore.rules` |
| 34 | Error/empty/offline handling | `Resource.Error` states, `NetworkUtils`, empty-state views on every list screen |
| 35 | Loading indicators | `ProgressBar` + `SyncState.Syncing` on every async operation |
| 36–37 | Deliverables / README | This file |

---

## 7. Firestore Data Model

```
users (collection)
  └── {uid} (document)
        email: string
        role: "ADMIN" | "USER"
        fcmToken: string | null
        devModeEnabled: boolean
        lastSyncAt: number (epoch millis)
        createdAt: number (epoch millis)
        │
        ├── contacts (sub-collection)
        │     └── {normalizedPhoneNumber} → { id, name, phoneNumber, email, syncedAt }
        │
        ├── callLogs (sub-collection)
        │     └── {number_timestamp} → { id, name, phoneNumber, callType,
        │                                durationSeconds, timestamp, syncedAt }
        │
        ├── sms (sub-collection)
        │     └── {sender_timestamp_bodyHash} → { id, sender, body, preview,
        │                                          timestamp, syncedAt }
        │
        └── records (sub-collection)                [generic CRUD feature]
              └── {autoId} → { id, title, description, createdAt, updatedAt }

app_config (collection, optional)
  └── global → { ...any app-wide flags, admin-write-only }
```

---

## 8. Security Rules Summary

See the fully-commented `firestore.rules` file. Key points:

- Every document under `users/{uid}/**` is readable and writable **only** by the
  authenticated user whose UID matches `{uid}` — one user can never read or write
  another user's contacts/call logs/SMS/records.
- A user cannot self-elevate their own `role` field to `"ADMIN"` via a client write;
  only an existing Admin (or a trusted backend using the Admin SDK, which bypasses
  rules) can change it. This is what the machine test's "prevent unauthorized
  CRUD/role escalation" requirement maps to.
- `app_config/global` is readable by any signed-in user but writable only by Admins,
  demonstrating role-gated Firestore writes end-to-end (client toggle in
  `AdminPanelFragment` → rule enforcement → Firestore).
- All non-matched paths are denied by default (`allow read, write: if false`).

---

## 9. Duplicate Prevention Strategy

Rather than reading everything into memory and diffing against what's already in
Firestore (expensive and racy), each synced item is written with a **deterministic
document ID** derived from its own natural key:

| Data type | Document ID formula |
|---|---|
| Contact | normalized phone number (last 10 digits) |
| Call log | `{digitsOfNumber}_{callTimestamp}` |
| SMS | `{digitsOfSender}_{timestamp}_{bodyHashCode}` |

Because Firestore's `set()` is an **upsert**, re-running sync (manually or via the
background worker) simply overwrites the same document with fresh data instead of
creating a new one — this is the core duplicate-prevention mechanism, and it's why
sync is safe to run as often as the WorkManager schedule (or the user) likes.

---

## 10. Sync Strategy (Manual / Automatic / Background)

- **Manual**: the Dashboard's "Sync Now" button calls `SyncManager.syncAll(uid)`
  directly, so the user gets instant progress feedback via `SyncState`.
- **Automatic/Background**: `SyncScheduler.schedulePeriodicSync()` enqueues a
  `PeriodicWorkRequest` for `SyncWorker` every 15 minutes (the WorkManager minimum),
  constrained to `NetworkType.CONNECTED`, with linear backoff retry on failure. It's
  scheduled once in `DataSyncApplication.onCreate()` and re-armed by
  `BootCompletedReceiver` after a device reboot.
- **Shared engine**: both paths call the exact same `SyncManager.syncAll()` function,
  so behavior (permission checks, duplicate prevention, error handling) never
  diverges between "the button" and "the background job."

---

## 11. Error & Edge Case Handling

| Scenario | Handling |
|---|---|
| No internet | `NetworkUtils.isConnected()` checked before every login/sync attempt; `Resource.Error("No internet connection...")` surfaces inline, not just as a toast |
| Authentication failure | `AuthRepositoryImpl.login()` catches `FirebaseAuthInvalidUserException` / `FirebaseAuthInvalidCredentialsException` and returns a friendly message shown on the Login screen |
| Permission denied | `DashboardFragment` shows a `MaterialAlertDialogBuilder` with a shortcut to App Settings |
| Firebase errors | Every repository wraps Firestore calls in try/catch → `Resource.Error` |
| Empty states | Every list screen (Contacts/CallLogs/SMS/Records) shows a dedicated empty-state view when the (filtered) list is empty |
| Sync failures | `SyncState.Error` surfaces a retry-able status label on the Dashboard; `SyncWorker` returns `Result.retry()` so WorkManager backs off and retries automatically |

---

## 12. Screenshots

> Screenshots are not included in this text-based deliverable. When preparing the final
> submission, run the app through the flows below and drop the corresponding PNGs into a
> `/screenshots` folder, referencing them here, e.g.:
>
> - `screenshots/01_splash.png`
> - `screenshots/02_login.png`
> - `screenshots/03_dashboard_user.png`
> - `screenshots/04_dashboard_admin_devmode.png`
> - `screenshots/05_contacts_search.png`
> - `screenshots/06_call_logs_filter.png`
> - `screenshots/07_sms_list.png`
> - `screenshots/08_records_crud.png`
> - `screenshots/09_admin_panel.png`
> - `screenshots/10_permission_dialog.png`

---

## 13. Building a Release APK

```bash
./gradlew assembleRelease
```
The APK will be at `app/build/outputs/apk/release/app-release.apk` (add a signing config
in `app/build.gradle.kts` for a distributable, signed build).

For a quick debug APK to sideload for testing:
```bash
./gradlew assembleDebug
# app/build/outputs/apk/debug/app-debug.apk
```

---

### Notes on what's intentionally out of scope

- No dedicated "Sign Up" screen was built since the task specifies *login* via
  Email/Username + Password; new users are provisioned via the Firebase Console (see
  section 1) exactly like an enterprise-internal tool would provision its very first
  accounts before self-serve signup (if any) is layered on top.
- Role elevation (`USER` → `ADMIN`) is done via the Firebase Console / Firestore Rules
  for this test, mirroring how a real internal tool would gate admin promotion behind
  a trusted backend rather than a client-side "become admin" button.
